Sejda-console application.

Documentation online
* Available at http://www.sejda.org/

Requirements
* Java Runtime 1.8 (or newer)

Quick install & run
* Extract the downloaded zip file
* (Linux/Mac) Grant execution permissions: > chmod +x bin/sejda-console
* (Linux/Mac) Execute the console: > ./bin/sejda-console
* (Windows) Execute bin/sejda-console.bat

License: GNU Affero GPLv3 
* Available at http://www.gnu.org/licenses/agpl-3.0.html

Feedbacks to: info@sejda.org
Issue tracker: https://github.com/torakiki/sejda/issues

Note: Application comes with ABSOLUTELY NO WARRANTY
